# Sign-Language-to-Text

Project converts American sign language to text in realtime. It uses CNN to train the required models for prediction. The dataset is custom made.

dataset : 
- train : https://drive.google.com/drive/u/1/folders/1-XTAjPPRPFeRqu3848z8dMXaolILWizn
- test : https://drive.google.com/drive/u/1/folders/18e1F1n1SWPF8lUF8pCKdUzSzKAbmSbVN

Demo : https://www.youtube.com/watch?v=aU5-8XJrxwY&t=2s
